from llm_helper import llm
from few_shots import FewShotPosts

few_shot = FewShotPosts()


def get_length_str(length):
    if length == "Short":
        return "1 to 10 lines"
    if length == "Medium":
        return "10 to 20 lines"
    if length == "Long":
        return "more than 20 lines"
    
def generate_post(length, language, tag):
    prompt = get_prompt(length, language, tag)
    response = llm.invoke(prompt)
    return response.content

def get_prompt(length, language, tag):
    length_str = get_length_str(length)

    prompt = f'''
    Generate a LinkedIn post using the below information. No preamble.

    1) Topic: {tag}
    2) Length: {length_str}
    3) Language: {language}
    If Language is Hinglish then it means it is a mix of Hindi and English. 
    The script for the generated post should always be English.
    '''

    examples = few_shot.get_filtered_posts(length, language, tag)

    if len(examples) > 0:
        prompt += """
        4) Use the writing style, tone, humour as per the following examples.
        Don't write the exact examples, rather take inspiration from them and be creative.
        For Hinglish posts, write only two-three lines of Hinglish and write the rest of the post in Emglish.
        Hinglish sentences can be in-between english sentences.
        """

    for i, post in enumerate(examples):
        post_text = post['text']
        prompt += f'\n\n Example {i+1}: \n\n {post_text}'

        if i == 1: 
            break

    return prompt

if __name__ == "__main__":
    print(generate_post("Long", "English", "Internship"))